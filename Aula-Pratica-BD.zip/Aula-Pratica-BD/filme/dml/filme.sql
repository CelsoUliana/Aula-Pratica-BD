-- populando com alguns valores
INSERT INTO filme.filme VALUES (1, 'Fight Club', 1999, 'David Fincher');
INSERT INTO filme.filme VALUES (2, 'Interestelar', 2016, 'Christopher Nolan');
INSERT INTO filme.filme VALUES (3, 'Home Alone 3', 1997, 'Raja Gosnell');
INSERT INTO filme.filme VALUES (4, 'The China Syndrome', 1979, 'James Bridges');

INSERT INTO filme.revisor VALUES (1, 'Bob Thomas');
INSERT INTO filme.revisor VALUES (2, 'Patrick Z. McGavin');

INSERT INTO filme.classificacao VALUES (1, 1, 0, 'Ugliest, most inhuman filme since Natural Born Killers');
INSERT INTO filme.classificacao VALUES (2, 1, 1, NULL);
INSERT INTO filme.classificacao VALUES (1, 3, 1, 'Nothing new about the series');
INSERT INTO filme.classificacao VALUES (1, 4, 5, 'Good tension');
